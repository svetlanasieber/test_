package softuni.exam.service.impl;

import org.springframework.stereotype.Service;
import softuni.exam.service.CountryService;

//ToDo - Implement all the methods
@Service
public class CountryServiceImpl implements CountryService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readCountryFileContent() {
        return null;
    }

    @Override
    public String importCountries() {
        return null;
    }
}
