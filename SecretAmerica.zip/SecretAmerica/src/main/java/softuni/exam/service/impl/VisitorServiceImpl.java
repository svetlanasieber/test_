package softuni.exam.service.impl;

import org.springframework.stereotype.Service;
import softuni.exam.service.VisitorService;

//ToDo - Implement all the methods

@Service
public class VisitorServiceImpl implements VisitorService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readVisitorsFileContent() {
        return null;
    }

    @Override
    public String importVisitors() {
        return null;
    }
}
