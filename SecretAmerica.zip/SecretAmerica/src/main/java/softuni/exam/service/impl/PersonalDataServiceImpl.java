package softuni.exam.service.impl;

import org.springframework.stereotype.Service;
import softuni.exam.service.PersonalDataService;

//ToDo - Implement all the methods

@Service
public class PersonalDataServiceImpl implements PersonalDataService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readPersonalDataFileContent() {
        return null;
    }

    @Override
    public String importPersonalData() {
        return null;
    }
}
