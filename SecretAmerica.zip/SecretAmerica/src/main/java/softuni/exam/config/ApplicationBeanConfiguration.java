package softuni.exam.config;

//ToDo Create configurations
public class ApplicationBeanConfiguration {
}
