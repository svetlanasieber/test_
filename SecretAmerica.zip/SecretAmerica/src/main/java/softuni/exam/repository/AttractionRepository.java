package softuni.exam.repository;

//ToDo:
public interface AttractionRepository {
}
