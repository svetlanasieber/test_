package softuni.exam.service.impl;

import org.springframework.stereotype.Service;
import softuni.exam.service.AttractionService;

//ToDo - Implement all the methods
@Service

public class AttractionServiceImpl implements AttractionService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readAttractionsFileContent() {
        return null;
    }

    @Override
    public String importAttractions() {
        return null;
    }

    @Override
    public String exportAttractions() {
        return null;
    }
}
